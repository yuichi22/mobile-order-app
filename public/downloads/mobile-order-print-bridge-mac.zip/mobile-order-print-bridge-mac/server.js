// server.js
// Mobile Order local print bridge for LAN ESC/POS printer
// Target: SII RP-D10 / LAN / RAW 9100

const iconv = require('iconv-lite');
const express = require('express');
const cors = require('cors');
const net = require('net');

const app = express();

app.use(cors());
app.use(express.json({ limit: '2mb' }));

const PRINTER_IP = process.env.PRINTER_IP || '192.168.0.100';
const PRINTER_PORT = Number(process.env.PRINTER_PORT || 9100);
const BRIDGE_PORT = Number(process.env.PORT || 8787);

// ラベルプリンタに最後に送ったラベルサイズ(D命令)のキー。同じサイズなら D + 頭出しFeed を
// 再送しない(再送ると毎回空送り＆位置ずれの原因)。サイズ/センサ変更時のみ再送する。
let lastLabelSizeKey = null;

const ESC = '\x1b';
const GS = '\x1d';

const FS = '\x1c';

const pushJapaneseMode = (chunks) => {
  // Initialize
  chunks.push(raw(`${ESC}@`));

  // International character set: Japan
  chunks.push(raw(`${ESC}R\x08`));

  // Character code table候補
  chunks.push(raw(`${ESC}t\x01`));

  // Kanji mode ON
  chunks.push(raw(`${FS}&`));

  // Kanji code system: Shift_JIS
  chunks.push(raw(`${FS}C\x01`));
};

const encodeText = (text = '') => {
  return iconv.encode(String(text), 'cp932');
};

const raw = (value = '') => {
  return Buffer.from(value, 'binary');
};

const formatYen = (value) => {
  const n = Math.round(Number(value || 0));
  return `¥${n.toLocaleString('ja-JP')}`;
};

const normalizeItemName = (item = {}) => {
  return (
    item.name ||
    item.itemName ||
    item.productName ||
    item.menuName ||
    item.title ||
    '商品'
  );
};

const normalizeQuantity = (item = {}) => {
  return Number(item.quantity ?? item.qty ?? item.count ?? 1) || 1;
};

const normalizeLineTotal = (item = {}) => {
  const quantity = normalizeQuantity(item);
  const explicitTotal =
    item.totalPrice ??
    item.lineTotal ??
    item.total ??
    item.amountTotal;

  if (explicitTotal != null) {
    return Number(explicitTotal) || 0;
  }

  const unitPrice =
    item.price ??
    item.unitPrice ??
    item.amount ??
    0;

  return (Number(unitPrice) || 0) * quantity;
};

const fitLine = (left, right, width = 32) => {
  const l = String(left || '');
  const r = String(right || '');
  const space = Math.max(width - l.length - r.length, 1);
  return `${l}${' '.repeat(space)}${r}`;
};

const sendToPrinter = (buffer, options = {}) => {
  const printerIp = options.printerIp || PRINTER_IP;
  const printerPort = Number(options.printerPort || PRINTER_PORT || 9100);

  return new Promise((resolve, reject) => {
    const socket = new net.Socket();

    let settled = false;

    const finish = () => {
      if (settled) return;
      settled = true;
      resolve();
    };

    const fail = (error) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      reject(error);
    };

    socket.setTimeout(5000);

    socket.connect(printerPort, printerIp, () => {
      socket.write(buffer, () => {
        socket.end();
        finish();
      });
    });

    socket.on('error', fail);

    socket.on('timeout', () => {
      fail(new Error(`Printer connection timeout: ${printerIp}:${printerPort}`));
    });
  });
};

const buildTestReceipt = () => {
  const chunks = [];

  // initialize
  chunks.push(raw(`${ESC}@`));
 pushJapaneseMode(chunks);

  // center
  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(encodeText('Mobile Order\n'));
  chunks.push(encodeText('印刷テスト\n'));
  chunks.push(encodeText('------------------------------\n'));

  // left
  chunks.push(raw(`${ESC}a\x00`));
  chunks.push(encodeText(`Printer: ${PRINTER_IP}:${PRINTER_PORT}\n`));
  chunks.push(encodeText(`Time: ${new Date().toLocaleString('ja-JP')}\n`));
  chunks.push(encodeText('------------------------------\n'));
  chunks.push(encodeText('テーブル: A1\n'));
  chunks.push(encodeText('商品: テスト商品\n'));
  chunks.push(encodeText('数量: 1\n'));
  chunks.push(encodeText(`金額: ${formatYen(500)}\n`));
  chunks.push(encodeText('------------------------------\n'));
  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(encodeText('ありがとうございました\n'));

  // feed
  chunks.push(encodeText('\n\n\n'));

  // partial/full cut
  chunks.push(raw(`${GS}V\x00`));

  return Buffer.concat(chunks);
};

const resolveAmount = (...values) => {
  for (const value of values) {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return 0;
};

const normalizePaymentMethodLabel = (method = '') => {
  const key = String(method || '').toLowerCase();
  if (key === 'cash') return '現金';
  if (key === 'card' || key === 'credit') return 'カード';
  if (key === 'qr' || key === 'paypay') return 'QR決済';
  return String(method || '');
};

const buildReceipt = (payload = {}) => {
  const {
    storeName = 'Mobile Order',
    tableName = '',
    receiptNo = '',
    issuedAtText = '',
    items = [],
    paymentMethod = '',
    title = '領収書',
    receiptScopeLabel = '',
    recipientLabel = '',
    recipientName = '',
    provisoLabel = '',
    proviso = '',
    hideRecipientAndProviso = false,
    note = ''
  } = payload;

  const subtotal = resolveAmount(payload.subtotal, payload.subTotal);
  const tax = resolveAmount(payload.tax, payload.taxAmount);
  const taxAmountReduced = resolveAmount(payload.taxAmountReduced);
  const taxAmountStandard = resolveAmount(payload.taxAmountStandard);
  const discountAmount = resolveAmount(payload.discountAmount, payload.discount);
  const total = resolveAmount(payload.total, payload.totalAmount, payload.totalPrice);
  const displayPaymentMethod = normalizePaymentMethodLabel(paymentMethod);

  const chunks = [];

  chunks.push(raw(`${ESC}@`));
  pushJapaneseMode(chunks);

  // header
  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(raw(`${ESC}!\x08`));
  chunks.push(encodeText(`${storeName}\n`));
  chunks.push(raw(`${ESC}!\x00`));
  chunks.push(encodeText(`${title || '領収書'}\n`));
  chunks.push(encodeText('------------------------------\n'));

  // body
  chunks.push(raw(`${ESC}a\x00`));

  if (receiptNo) {
    chunks.push(encodeText(`No: ${receiptNo}\n`));
  }

  chunks.push(encodeText(`${issuedAtText || new Date().toLocaleString('ja-JP')}\n`));

  if (tableName) {
    chunks.push(encodeText(`テーブル: ${tableName}\n`));
  }

  if (receiptScopeLabel) {
    chunks.push(encodeText(`区分: ${receiptScopeLabel}\n`));
  }

  if (!hideRecipientAndProviso) {
    const resolvedRecipient = recipientLabel || (recipientName ? `${recipientName} 様` : '様');
    const resolvedProviso = provisoLabel || (proviso ? `${proviso} として` : 'として');
    chunks.push(encodeText(`宛名: ${resolvedRecipient}\n`));
    chunks.push(encodeText(`但し: ${resolvedProviso}\n`));
  }

  chunks.push(encodeText('------------------------------\n'));

  const normalizedItems = Array.isArray(items) ? items : [];
  if (normalizedItems.length === 0) {
    chunks.push(encodeText('商品明細なし\n'));
  }

  for (const item of normalizedItems) {
    const name = normalizeItemName(item);
    const quantity = normalizeQuantity(item);
    const unitPrice = resolveAmount(item.unitPrice, item.price, item.amount);
    const lineTotal = normalizeLineTotal(item);

    chunks.push(encodeText(`${name}\n`));

    if (unitPrice > 0 && quantity > 0) {
      chunks.push(encodeText(`  ${formatYen(unitPrice)} x ${quantity}  ${formatYen(lineTotal)}\n`));
    } else {
      chunks.push(encodeText(`  ${formatYen(lineTotal)}\n`));
    }
  }

  chunks.push(encodeText('------------------------------\n'));

  if (discountAmount > 0) {
    chunks.push(encodeText(`${fitLine('値引き', `-${formatYen(discountAmount)}`)}\n`));
  }

  chunks.push(encodeText(`${fitLine('小計', formatYen(subtotal))}\n`));

  if (taxAmountReduced > 0) {
    chunks.push(encodeText(`${fitLine('消費税 8%', formatYen(taxAmountReduced))}\n`));
  }

  if (taxAmountStandard > 0) {
    chunks.push(encodeText(`${fitLine('消費税 10%', formatYen(taxAmountStandard))}\n`));
  }

  if (taxAmountReduced === 0 && taxAmountStandard === 0) {
    chunks.push(encodeText(`${fitLine('税額', formatYen(tax))}\n`));
  }

  chunks.push(raw(`${ESC}!\x08`));
  chunks.push(encodeText(`${fitLine('合計', formatYen(total))}\n`));
  chunks.push(raw(`${ESC}!\x00`));

  if (displayPaymentMethod) {
    chunks.push(encodeText(`${fitLine('支払方法', displayPaymentMethod)}\n`));
  }

  if (note) {
    chunks.push(encodeText('------------------------------\n'));
    const text = String(note || '');
    const width = 30;
    for (let i = 0; i < text.length; i += width) {
      chunks.push(encodeText(`${text.slice(i, i + width)}\n`));
    }
  }

  chunks.push(encodeText('------------------------------\n'));

  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(encodeText(title === '会計明細' ? '会計内訳です\n' : 'ありがとうございました\n'));
  chunks.push(encodeText('\n\n\n'));

  chunks.push(raw(`${GS}V\x00`));

  return Buffer.concat(chunks);
};

// ============================================================
// ラベル印刷（東芝テック B-EV4T / TPCL / RAW TCP 9100）
// ------------------------------------------------------------
// TPCL (TEC Printer Command Language) でバーコードラベルを生成する。
// 制御コードは標準モード（ヘッダ '{' / 区切り '|' / 終端 '}'）で、
// 各コマンドは `{` で始まり `|}` で終わる。座標・寸法はすべて 0.1mm 単位。
//
// ※ XB(バーコード)/PC(文字)/XS(発行) の細かな引数は B-EV4T の TPCL
//   リファレンス依存。実機で1枚通しながら調整する前提で、レイアウト値・
//   倍率・モジュール幅・濃度・速度は payload / 既定値から可変にしている。
// ============================================================

// アプリ側のバーコード種別名 → TPCL XB コマンドのバーコードタイプ。
const TPCL_BARCODE_TYPE = {
  jan13: '5', // JAN13 / EAN13
  ean13: '5',
  jan8: '0', // JAN8 / EAN8
  ean8: '0',
  code128: '9', // CODE128
  code39: '3', // CODE39
  nw7: '4', // NW-7 (Codabar)
  itf: '2' // Interleaved 2 of 5
};

// 0.1mm 値を 4 桁ゼロ詰めへ。
const tpclCoord = (value) => String(Math.max(0, Math.round(Number(value) || 0))).padStart(4, '0');

// TPCL のデータフィールドに使えない制御文字（| や 改行）を除去する。
const sanitizeTpclText = (text = '') =>
  String(text == null ? '' : text)
    .replace(/[|{}]/g, ' ')
    .replace(/[\r\n\t]/g, ' ')
    .trim();

// 文字列のおおよその印字幅(0.1mm)。右寄せ位置の概算用(font B 基準・実機で要調整)。
// 全角(コードポイント>0xFF)は約1.5mm、半角は約0.9mm × 横倍率。
const estimateTextWidthU = (text = '', widthMag = 1) => {
  let units = 0;
  for (const ch of String(text)) {
    const code = ch.codePointAt(0);
    units += (code > 0xff ? 15 : 9) * widthMag;
  }
  return units;
};

// 1 枚分のラベル TPCL を組み立てる。
const buildLabelCommands = (label = {}, options = {}) => {
  const {
    symbology = 'code128',
    labelWidthMm = 30,
    moduleWidthDots = 2,
    barcodeHeightMm = 5,
    showName = true,
    showPrice = true,
    showBarcodeNumber = false
  } = options;

  const barcodeType = TPCL_BARCODE_TYPE[String(symbology).toLowerCase()] || '9';
  const widthU = Math.round(labelWidthMm * 10);
  // 印字可能域 約1mm〜12mm(13mmラベル, 上下1mmはスローアップ/ダウンで印字不可)に収める。
  // 番号(バーコード下の数字)を出す時は、その2.0mm分の余白を作るためバーコードを低めにする。
  const showNum = Boolean(showBarcodeNumber);
  // 印字可能下端は約110(下端2mmは減速ゾーンで印字不可)。バーコード上端 y=66。
  // 番号ON時はバー下端を約84に抑え、その下(番号 帯86-106)に番号。番号OFF時はバーを約106まで。
  const barcodeH = Math.min(Math.round(barcodeHeightMm * 10), showNum ? 18 : 40);
  const mw = String(Math.max(1, Math.min(15, moduleWidthDots))).padStart(2, '0');

  const sku = sanitizeTpclText(label.sku);
  const name = sanitizeTpclText(label.name);
  const colorName = sanitizeTpclText(label.colorName);
  const size = sanitizeTpclText(label.size);
  const barcodeData = sanitizeTpclText(label.barcode);
  const price = label.price != null && label.price !== '' ? formatYen(label.price) : '';

  // レイアウト（0.1mm単位 / 例 30×13mm = widthU 300）:
  //  1段目: 品番(左) ／ 税込・価格(右)
  //  2段目: 名称(太)
  //  3段目: バーコード(左) ／ 色(右上)・サイズ(右下)
  // ※座標・倍率は B-EV4T 実機で調整する前提。バーコード幅が広いと右側の色/サイズと
  //   重なるため、モジュール幅(細さ)や barcodeSource(品番/JAN) で調整する。
  const xL = 12; // 左マージン
  const rightMargin = 8; // 右マージン(右寄せ用)
  // 右寄せのX座標を文字幅から逆算する。
  const rightAlignedX = (text, widthMag = 1) =>
    Math.max(xL, widthU - rightMargin - estimateTextWidthU(text, widthMag));

  const commands = ['{C|}'];

  // TPCL BIT MAP FONT (PC) コマンド書式（B-EV4仕様）:
  //   {PCnnn;X,Y,横倍率,縦倍率,フォント,回転(2桁),属性=データ|}
  //   ・データは「=」で渡す。回転2桁。属性B=黒文字。フォントU=漢字16x16(ANK+漢字)。
  //   ★文字の印字原点 Y は「文字の下端」基準で、文字は上方向に描かれる。
  //     よって各PCの Y = その文字の下端(0.1mm)。バーコード(XB)の Y は上端でバーは下方向。
  const F = 'U';

  // バーコード幅(JAN13概算)。色/サイズの左詰め開始位置に使う。
  const barcodeWidthU = Math.round(95 * Math.max(1, moduleWidthDots) * 1.25);
  // 色/サイズは「バーコード右端の少し右」から左詰め。ただしラベル右端からはみ出さないよう、
  // 文字が必ず収まる左寄り位置(右端から最大8mmぶん手前)にクランプ。
  const xRightCol = Math.min(xL + barcodeWidthU + 6, widthU - 80);

  // 縦座標(0.1mm, 文字Yは下端)。印字可能域 約10〜110(下端2mmは印字不可)に収める。
  const yKuban = 30; // 品番(下端)
  const yPrice = 46; // 価格(下端, 大きめ太字)
  const yName = 64; // 名称(下端)
  const yBarTop = 66; // バーコード上端(バーは下方向)
  const yColor = 84; // 色(下端)
  const yBottom = 106; // サイズ/番号(下端)

  // 1段目: 品番(左) ／ 価格(右)。価格は「¥金額=太字大(フォントC)」＋「税込=小(フォントU)」。
  if (sku) {
    commands.push(`{PC001;${tpclCoord(xL)},${tpclCoord(yKuban)},1,1,${F},00,B=品番：${sku}|}`);
  }
  if (showPrice && price) {
    const tax = '税込';
    const taxW = estimateTextWidthU(tax, 1); // 税込(フォントU)幅
    const xTax = Math.max(xL, widthU - rightMargin - taxW); // 税込を右端に
    // ¥金額: フォントC(Times Bold)で太字・大きめ。幅は概算(1文字≈18)。税込の左に配置。
    const yenW = price.length * 18;
    const xYen = Math.max(xL, xTax - 6 - yenW);
    commands.push(`{PC002;${tpclCoord(xYen)},${tpclCoord(yPrice)},1,1,C,00,B=${price}|}`);
    commands.push(`{PC003;${tpclCoord(xTax)},${tpclCoord(yPrice)},1,1,${F},00,B=${tax}|}`);
  }

  // 2段目（名称）
  if (showName && name) {
    commands.push(`{PC004;${tpclCoord(xL)},${tpclCoord(yName)},1,1,${F},00,B=名称|}`);
    commands.push(`{PC005;${tpclCoord(xL + 44)},${tpclCoord(yName)},1,1,${F},00,B=${name}|}`);
  }

  // 3段目（バーコード=左 ／ 色=右上・サイズ=右下を左詰め ／ 番号=バーコード下）
  if (barcodeData) {
    commands.push(`{XB01;${tpclCoord(xL)},${tpclCoord(yBarTop)},${barcodeType},1,${mw},0,${tpclCoord(barcodeH)}=${barcodeData}|}`);
    // バーコード番号: 文字間隔を空けてバーコード幅いっぱいに広げる。
    if (showNum) {
      const n = barcodeData.length;
      const digitsW = n * 9; // フォントU半角概算
      // 余り幅を文字間に均等配分→dot換算(1dot=1.25/0.1mm)。0〜30dotにクランプ。
      const spaceDots = Math.max(0, Math.min(30, Math.round((barcodeWidthU - digitsW) / Math.max(1, n - 1) / 1.25)));
      const gh = `+${String(spaceDots).padStart(2, '0')}`;
      commands.push(`{PC008;${tpclCoord(xL + 4)},${tpclCoord(yBottom)},1,1,${F},${gh},00,B=${barcodeData}|}`);
    }
  }
  // 色・サイズ：バーコード右側に左詰め
  if (colorName) {
    commands.push(`{PC006;${tpclCoord(xRightCol)},${tpclCoord(yColor)},1,1,${F},00,B=${colorName}|}`);
  }
  if (size) {
    commands.push(`{PC007;${tpclCoord(xRightCol)},${tpclCoord(yBottom)},1,1,${F},00,B=${size}|}`);
  }

  return commands;
};

const buildLabelTPCL = (payload = {}) => {
  const {
    labels = [],
    labelWidthMm = 30, // ラベル幅（印字ヘッド方向＝Xの有効幅）
    labelHeightMm = 13, // ラベル送り方向の長さ
    gapMm = 0, // ラベル間ギャップ（隙間）。黒線連続紙は 0
    mediaSensor = 'blackmark', // 用紙センサー: blackmark=反射/gap=透過/none=なし
    printSpeed = 3, // 印字速度(ips相当の指定値)。実機に合わせ調整。
    copies = 1
  } = payload;

  // 発行(XS)コマンドのセンサー種別digit。2=透過(ギャップ) / 1=反射(ブラックマーク) / 0=なし(連続)
  const sensorDigit = { gap: '2', blackmark: '1', none: '0' }[String(mediaSensor).toLowerCase()] || '2';

  const widthU = Math.round(labelWidthMm * 10);
  const pitchU = Math.round((labelHeightMm + Number(gapMm || 0)) * 10); // ピッチ = ラベル長 + ギャップ
  // 有効印字長＝ピッチ(=ラベル長)に合わせる。
  // ※以前これより短く(2mm余白)したら、印字停止位置が黒線(ホーム)よりずれた状態で D が
  //   メモリ保持され、印刷後にFEEDが狂う(電源OFFでも直らない)不具合になった。停止位置を
  //   黒線=ピッチに合わせることで回避する。
  const heightU = Math.round(labelHeightMm * 10);
  void lastLabelSizeKey; // 互換のため残置(未使用)

  const lines = [];

  // ラベルサイズ設定(毎回同じ値を送る。停止位置=黒線になるためFEEDは狂わない)。
  lines.push(`{D${tpclCoord(pitchU)},${tpclCoord(widthU)},${tpclCoord(heightU)}|}`);

  const normalizedLabels = Array.isArray(labels) ? labels : [];

  for (const label of normalizedLabels) {
    const labelCopies = Math.max(1, Math.min(999, Number(label.copies ?? copies ?? 1)));

    lines.push(...buildLabelCommands(label, { ...payload, labelHeightMm }));

    // 発行: {XS;I, 枚数, 000<センサ>C<速度><リボン><回転><応答> |}
    //  例 {XS;I,0001,0001C3000|} = カット無し/反射センサ/速度3/直感熱(リボン0)/回転0/応答無し
    //  センサ digit: 2=透過 1=反射(黒線) 0=なし。カッタ構成に合わせ先頭3桁は000(カット無し)。
    lines.push(
      `{XS;I,${String(labelCopies).padStart(4, '0')},000${sensorDigit}C${String(printSpeed).padStart(1, '0')}000|}`
    );
  }

  // 各コマンドは CR+LF 区切りで送出する。日本語(税込/名称/商品名)を含むため
  // Shift-JIS(CP932)でエンコードする。latin1だと日本語が化けてTPCLの区切り(|})を壊す。
  return iconv.encode(lines.join('\r\n') + '\r\n', 'cp932');
};

app.get('/health', (req, res) => {
  res.json({
    ok: true,
    bridge: 'mobile-order-print-bridge',
    printerIp: PRINTER_IP,
    printerPort: PRINTER_PORT,
    bridgePort: BRIDGE_PORT
  });
});

app.post('/print/test', async (req, res) => {
  try {
    const payload = req.body || {};
    const printerIp = payload.printerIp || PRINTER_IP;
    const printerPort = Number(payload.printerPort || PRINTER_PORT || 9100);

    console.log('');
    console.log('========================================');
    console.log('[print test request]');
    console.log('printerIp:', printerIp);
    console.log('printerPort:', printerPort);
    console.log('========================================');
    console.log('');

    const buffer = buildTestReceipt();
    await sendToPrinter(buffer, {
      printerIp,
      printerPort
    });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print test error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.post('/print/receipt', async (req, res) => {
  try {
    const payload = req.body || {};

    console.log('');
    console.log('========================================');
    console.log('[print receipt request]');
    console.log('storeName:', payload.storeName);
    console.log('tableName:', payload.tableName);
    console.log('receiptNo:', payload.receiptNo);
    console.log('items:', Array.isArray(payload.items) ? payload.items.length : 0);
    console.log('subtotal:', payload.subtotal);
    console.log('tax:', payload.tax);
    console.log('total:', payload.total);
    console.log('paymentMethod:', payload.paymentMethod);
    console.log('printerIp:', payload.printerIp || PRINTER_IP);
    console.log('printerPort:', payload.printerPort || PRINTER_PORT);
    console.log('========================================');
    console.log('');

    const buffer = buildReceipt(payload);

    await sendToPrinter(buffer, {
    printerIp: payload.printerIp,
    printerPort: payload.printerPort
    });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print receipt error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.post('/print/label', async (req, res) => {
  try {
    const payload = req.body || {};
    const printerIp = payload.printerIp || PRINTER_IP;
    const printerPort = Number(payload.printerPort || payload.port || PRINTER_PORT || 9100);
    const labels = Array.isArray(payload.labels) ? payload.labels : [];

    console.log('');
    console.log('========================================');
    console.log('[print label request]');
    console.log('printerIp:', printerIp);
    console.log('printerPort:', printerPort);
    console.log('labels:', labels.length);
    console.log('symbology:', payload.symbology);
    console.log('mediaSensor:', payload.mediaSensor);
    console.log('labelSize:', `${payload.labelWidthMm}x${payload.labelHeightMm}mm gap=${payload.gapMm}`);
    console.log('========================================');
    console.log('');

    if (labels.length === 0) {
      res.status(400).json({ ok: false, error: '印刷するラベルがありません' });
      return;
    }

    const buffer = buildLabelTPCL(payload);

    console.log('---- TPCL ----');
    console.log(buffer.toString('latin1'));
    console.log('---- /TPCL ----');
    console.log('');

    await sendToPrinter(buffer, { printerIp, printerPort });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print label error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.listen(BRIDGE_PORT, () => {
  console.log('');
  console.log('========================================');
  console.log(' Mobile Order Print Bridge');
  console.log('========================================');
  console.log(`Bridge URL : http://localhost:${BRIDGE_PORT}`);
  console.log(`Printer    : ${PRINTER_IP}:${PRINTER_PORT}`);
  console.log('');
  console.log('Health check:');
  console.log(`curl http://localhost:${BRIDGE_PORT}/health`);
  console.log('');
  console.log('Test print:');
  console.log(`curl -X POST http://localhost:${BRIDGE_PORT}/print/test`);
  console.log('========================================');
  console.log('');
});