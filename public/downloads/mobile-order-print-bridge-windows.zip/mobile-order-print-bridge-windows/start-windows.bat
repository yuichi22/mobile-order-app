@echo off
cd /d %~dp0

echo.
echo ========================================
echo  Mobile Order Print Bridge
echo ========================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo Node.js が見つかりません。
  echo 先に Node.js をインストールしてください。
  echo https://nodejs.org/
  echo.
  pause
  exit /b 1
)

if not exist node_modules (
  echo 初回起動のため、必要なパッケージをインストールします...
  npm install
)

echo.
echo 印刷ブリッジを起動します。
echo このウィンドウは閉じないでください。
echo.

npm start

echo.
pause
