@echo off
cd /d %~dp0

echo.
echo ========================================
echo  Mobile Order Print Bridge
echo ========================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo Node.js が見つかりません。
  echo 先に Node.js をインストールしてから、もう一度このファイルを実行してください。
  echo https://nodejs.org/
  echo.
  pause
  exit /b 1
)

if not exist node_modules (
  echo 初回起動のため、必要なパッケージをインストールします...
  call npm install
  if %errorlevel% neq 0 (
    echo.
    echo パッケージのインストールに失敗しました。
    echo インターネット接続を確認して、もう一度実行してください。
    echo.
    pause
    exit /b 1
  )
)

echo.
echo 印刷ブリッジを起動します。
echo このウィンドウは閉じないでください。
echo.

call npm start

echo.
echo 印刷ブリッジが停止しました。ウィンドウを閉じて構いません。
pause
