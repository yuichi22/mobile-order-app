// server.js
// Mobile Order local print bridge for LAN ESC/POS printer
// Target: SII RP-D10 / LAN / RAW 9100

const iconv = require('iconv-lite');
const express = require('express');
const cors = require('cors');
const net = require('net');

const app = express();

app.use(cors());
app.use(express.json({ limit: '2mb' }));

const PRINTER_IP = process.env.PRINTER_IP || '192.168.0.100';
const PRINTER_PORT = Number(process.env.PRINTER_PORT || 9100);
const BRIDGE_PORT = Number(process.env.PORT || 8787);

const ESC = '\x1b';
const GS = '\x1d';

const FS = '\x1c';

const pushJapaneseMode = (chunks) => {
  // Initialize
  chunks.push(raw(`${ESC}@`));

  // International character set: Japan
  chunks.push(raw(`${ESC}R\x08`));

  // Character code table候補
  chunks.push(raw(`${ESC}t\x01`));

  // Kanji mode ON
  chunks.push(raw(`${FS}&`));

  // Kanji code system: Shift_JIS
  chunks.push(raw(`${FS}C\x01`));
};

const encodeText = (text = '') => {
  return iconv.encode(String(text), 'cp932');
};

const raw = (value = '') => {
  return Buffer.from(value, 'binary');
};

const formatYen = (value) => {
  const n = Math.round(Number(value || 0));
  return `¥${n.toLocaleString('ja-JP')}`;
};

const normalizeItemName = (item = {}) => {
  return (
    item.name ||
    item.itemName ||
    item.productName ||
    item.menuName ||
    item.title ||
    '商品'
  );
};

const normalizeQuantity = (item = {}) => {
  return Number(item.quantity ?? item.qty ?? item.count ?? 1) || 1;
};

const normalizeLineTotal = (item = {}) => {
  const quantity = normalizeQuantity(item);
  const explicitTotal =
    item.totalPrice ??
    item.lineTotal ??
    item.total ??
    item.amountTotal;

  if (explicitTotal != null) {
    return Number(explicitTotal) || 0;
  }

  const unitPrice =
    item.price ??
    item.unitPrice ??
    item.amount ??
    0;

  return (Number(unitPrice) || 0) * quantity;
};

const fitLine = (left, right, width = 32) => {
  const l = String(left || '');
  const r = String(right || '');
  const space = Math.max(width - l.length - r.length, 1);
  return `${l}${' '.repeat(space)}${r}`;
};

const sendToPrinter = (buffer, options = {}) => {
  const printerIp = options.printerIp || PRINTER_IP;
  const printerPort = Number(options.printerPort || PRINTER_PORT || 9100);

  return new Promise((resolve, reject) => {
    const socket = new net.Socket();

    let settled = false;

    const finish = () => {
      if (settled) return;
      settled = true;
      resolve();
    };

    const fail = (error) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      reject(error);
    };

    socket.setTimeout(5000);

    socket.connect(printerPort, printerIp, () => {
      socket.write(buffer, () => {
        socket.end();
        finish();
      });
    });

    socket.on('error', fail);

    socket.on('timeout', () => {
      fail(new Error(`Printer connection timeout: ${printerIp}:${printerPort}`));
    });
  });
};

const buildTestReceipt = () => {
  const chunks = [];

  // initialize
  chunks.push(raw(`${ESC}@`));
 pushJapaneseMode(chunks);

  // center
  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(encodeText('Mobile Order\n'));
  chunks.push(encodeText('印刷テスト\n'));
  chunks.push(encodeText('------------------------------\n'));

  // left
  chunks.push(raw(`${ESC}a\x00`));
  chunks.push(encodeText(`Printer: ${PRINTER_IP}:${PRINTER_PORT}\n`));
  chunks.push(encodeText(`Time: ${new Date().toLocaleString('ja-JP')}\n`));
  chunks.push(encodeText('------------------------------\n'));
  chunks.push(encodeText('テーブル: A1\n'));
  chunks.push(encodeText('商品: テスト商品\n'));
  chunks.push(encodeText('数量: 1\n'));
  chunks.push(encodeText(`金額: ${formatYen(500)}\n`));
  chunks.push(encodeText('------------------------------\n'));
  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(encodeText('ありがとうございました\n'));

  // feed
  chunks.push(encodeText('\n\n\n'));

  // partial/full cut
  chunks.push(raw(`${GS}V\x00`));

  return Buffer.concat(chunks);
};

const resolveAmount = (...values) => {
  for (const value of values) {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return 0;
};

const normalizePaymentMethodLabel = (method = '') => {
  const key = String(method || '').toLowerCase();
  if (key === 'cash') return '現金';
  if (key === 'card' || key === 'credit') return 'カード';
  if (key === 'qr' || key === 'paypay') return 'QR決済';
  return String(method || '');
};

const buildReceipt = (payload = {}) => {
  const {
    storeName = 'Mobile Order',
    tableName = '',
    receiptNo = '',
    issuedAtText = '',
    items = [],
    paymentMethod = '',
    title = '領収書',
    receiptScopeLabel = '',
    recipientLabel = '',
    recipientName = '',
    provisoLabel = '',
    proviso = '',
    hideRecipientAndProviso = false,
    note = ''
  } = payload;

  const subtotal = resolveAmount(payload.subtotal, payload.subTotal);
  const tax = resolveAmount(payload.tax, payload.taxAmount);
  const taxAmountReduced = resolveAmount(payload.taxAmountReduced);
  const taxAmountStandard = resolveAmount(payload.taxAmountStandard);
  const discountAmount = resolveAmount(payload.discountAmount, payload.discount);
  const total = resolveAmount(payload.total, payload.totalAmount, payload.totalPrice);
  const displayPaymentMethod = normalizePaymentMethodLabel(paymentMethod);

  const chunks = [];

  chunks.push(raw(`${ESC}@`));
  pushJapaneseMode(chunks);

  // header
  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(raw(`${ESC}!\x08`));
  chunks.push(encodeText(`${storeName}\n`));
  chunks.push(raw(`${ESC}!\x00`));
  chunks.push(encodeText(`${title || '領収書'}\n`));
  chunks.push(encodeText('------------------------------\n'));

  // body
  chunks.push(raw(`${ESC}a\x00`));

  if (receiptNo) {
    chunks.push(encodeText(`No: ${receiptNo}\n`));
  }

  chunks.push(encodeText(`${issuedAtText || new Date().toLocaleString('ja-JP')}\n`));

  if (tableName) {
    chunks.push(encodeText(`テーブル: ${tableName}\n`));
  }

  if (receiptScopeLabel) {
    chunks.push(encodeText(`区分: ${receiptScopeLabel}\n`));
  }

  if (!hideRecipientAndProviso) {
    const resolvedRecipient = recipientLabel || (recipientName ? `${recipientName} 様` : '様');
    const resolvedProviso = provisoLabel || (proviso ? `${proviso} として` : 'として');
    chunks.push(encodeText(`宛名: ${resolvedRecipient}\n`));
    chunks.push(encodeText(`但し: ${resolvedProviso}\n`));
  }

  chunks.push(encodeText('------------------------------\n'));

  const normalizedItems = Array.isArray(items) ? items : [];
  if (normalizedItems.length === 0) {
    chunks.push(encodeText('商品明細なし\n'));
  }

  for (const item of normalizedItems) {
    const name = normalizeItemName(item);
    const quantity = normalizeQuantity(item);
    const unitPrice = resolveAmount(item.unitPrice, item.price, item.amount);
    const lineTotal = normalizeLineTotal(item);

    chunks.push(encodeText(`${name}\n`));

    if (unitPrice > 0 && quantity > 0) {
      chunks.push(encodeText(`  ${formatYen(unitPrice)} x ${quantity}  ${formatYen(lineTotal)}\n`));
    } else {
      chunks.push(encodeText(`  ${formatYen(lineTotal)}\n`));
    }
  }

  chunks.push(encodeText('------------------------------\n'));

  if (discountAmount > 0) {
    chunks.push(encodeText(`${fitLine('値引き', `-${formatYen(discountAmount)}`)}\n`));
  }

  chunks.push(encodeText(`${fitLine('小計', formatYen(subtotal))}\n`));

  if (taxAmountReduced > 0) {
    chunks.push(encodeText(`${fitLine('消費税 8%', formatYen(taxAmountReduced))}\n`));
  }

  if (taxAmountStandard > 0) {
    chunks.push(encodeText(`${fitLine('消費税 10%', formatYen(taxAmountStandard))}\n`));
  }

  if (taxAmountReduced === 0 && taxAmountStandard === 0) {
    chunks.push(encodeText(`${fitLine('税額', formatYen(tax))}\n`));
  }

  chunks.push(raw(`${ESC}!\x08`));
  chunks.push(encodeText(`${fitLine('合計', formatYen(total))}\n`));
  chunks.push(raw(`${ESC}!\x00`));

  if (displayPaymentMethod) {
    chunks.push(encodeText(`${fitLine('支払方法', displayPaymentMethod)}\n`));
  }

  if (note) {
    chunks.push(encodeText('------------------------------\n'));
    const text = String(note || '');
    const width = 30;
    for (let i = 0; i < text.length; i += width) {
      chunks.push(encodeText(`${text.slice(i, i + width)}\n`));
    }
  }

  chunks.push(encodeText('------------------------------\n'));

  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(encodeText(title === '会計明細' ? '会計内訳です\n' : 'ありがとうございました\n'));
  chunks.push(encodeText('\n\n\n'));

  chunks.push(raw(`${GS}V\x00`));

  return Buffer.concat(chunks);
};

// ============================================================
// ラベル印刷（東芝テック B-EV4T / TPCL / RAW TCP 9100）
// ------------------------------------------------------------
// TPCL (TEC Printer Command Language) でバーコードラベルを生成する。
// 制御コードは標準モード（ヘッダ '{' / 区切り '|' / 終端 '}'）で、
// 各コマンドは `{` で始まり `|}` で終わる。座標・寸法はすべて 0.1mm 単位。
//
// ※ XB(バーコード)/PC(文字)/XS(発行) の細かな引数は B-EV4T の TPCL
//   リファレンス依存。実機で1枚通しながら調整する前提で、レイアウト値・
//   倍率・モジュール幅・濃度・速度は payload / 既定値から可変にしている。
// ============================================================

// アプリ側のバーコード種別名 → TPCL XB コマンドのバーコードタイプ。
const TPCL_BARCODE_TYPE = {
  jan13: '5', // JAN13 / EAN13
  ean13: '5',
  jan8: '0', // JAN8 / EAN8
  ean8: '0',
  code128: '9', // CODE128
  code39: '3', // CODE39
  nw7: '4', // NW-7 (Codabar)
  itf: '2' // Interleaved 2 of 5
};

// 0.1mm 値を 4 桁ゼロ詰めへ。
const tpclCoord = (value) => String(Math.max(0, Math.round(Number(value) || 0))).padStart(4, '0');

// TPCL のデータフィールドに使えない制御文字（| や 改行）を除去する。
const sanitizeTpclText = (text = '') =>
  String(text == null ? '' : text)
    .replace(/[|{}]/g, ' ')
    .replace(/[\r\n\t]/g, ' ')
    .trim();

// 1 枚分のラベル TPCL を組み立てる。
const buildLabelCommands = (label = {}, options = {}) => {
  const {
    symbology = 'jan13',
    labelHeightMm = 30,
    showName = true,
    showPrice = true,
    moduleWidthDots = 3, // バーコード1モジュール幅(dot)。203dpi で 2-4 が目安。
    barcodeHeightMm = 12
  } = options;

  const barcodeType = TPCL_BARCODE_TYPE[String(symbology).toLowerCase()] || '5';
  const heightU = Math.round(labelHeightMm * 10);
  const barcodeHeightU = Math.round(barcodeHeightMm * 10);

  const barcodeData = sanitizeTpclText(label.barcode);
  const name = sanitizeTpclText(label.name);
  const price = label.price != null && label.price !== '' ? formatYen(label.price) : '';

  const commands = [];

  // 画像バッファをクリア
  commands.push('{C|}');

  // 商品名（上部）。font B / 等倍 / 0°回転。
  if (showName && name) {
    commands.push(`{PC001;${tpclCoord(20)},${tpclCoord(20)},1,1,B,0,B|${name}|}`);
  }

  // バーコード。{XBnn; X, Y, type, checkdigit, モジュール幅, 回転, 高さ |data|}
  if (barcodeData) {
    const barY = showName ? 90 : 50;
    commands.push(
      `{XB01;${tpclCoord(40)},${tpclCoord(barY)},${barcodeType},1,${String(Math.max(1, Math.min(15, moduleWidthDots))).padStart(2, '0')},0,${tpclCoord(barcodeHeightU)}|${barcodeData}|}`
    );
  }

  // 価格（下部）。font B / 2倍。
  if (showPrice && price) {
    commands.push(`{PC002;${tpclCoord(20)},${tpclCoord(heightU - 70)},2,2,B,0,B|${price}|}`);
  }

  return commands;
};

const buildLabelTPCL = (payload = {}) => {
  const {
    labels = [],
    labelWidthMm = 40, // ラベル幅（印字ヘッド方向＝Xの有効幅）
    labelHeightMm = 30, // ラベル送り方向の長さ
    gapMm = 3, // ラベル間ギャップ（隙間）。連続紙は 0
    printSpeed = 3, // 印字速度(ips相当の指定値)。実機に合わせ調整。
    printDensity = 3, // 印字濃度(細かな範囲は機種依存)。
    copies = 1
  } = payload;

  const widthU = Math.round(labelWidthMm * 10);
  const heightU = Math.round(labelHeightMm * 10);
  const pitchU = Math.round((labelHeightMm + Number(gapMm || 0)) * 10); // ピッチ = ラベル長 + ギャップ

  const lines = [];

  // ラベルサイズ設定: {D ピッチ, 印字有効幅, 印字有効長 |}
  lines.push(`{D${tpclCoord(pitchU)},${tpclCoord(widthU)},${tpclCoord(heightU)}|}`);

  const normalizedLabels = Array.isArray(labels) ? labels : [];

  for (const label of normalizedLabels) {
    const labelCopies = Math.max(1, Math.min(999, Number(label.copies ?? copies ?? 1)));

    lines.push(...buildLabelCommands(label, { ...payload, labelHeightMm }));

    // 発行: {XS;I, 枚数, 切断間隔/センサ/速度/濃度 |}
    // 末尾の "C" 以降（切断・速度・濃度）は B-EV4T のセンサ/カッタ構成に合わせて要調整。
    lines.push(
      `{XS;I,${String(labelCopies).padStart(4, '0')},0002C${String(printSpeed).padStart(1, '0')}${String(printDensity).padStart(2, '0')}|}`
    );
  }

  // 各コマンドは CR+LF 区切りで送出する。
  return Buffer.from(lines.join('\r\n') + '\r\n', 'binary');
};

app.get('/health', (req, res) => {
  res.json({
    ok: true,
    bridge: 'mobile-order-print-bridge',
    printerIp: PRINTER_IP,
    printerPort: PRINTER_PORT,
    bridgePort: BRIDGE_PORT
  });
});

app.post('/print/test', async (req, res) => {
  try {
    const payload = req.body || {};
    const printerIp = payload.printerIp || PRINTER_IP;
    const printerPort = Number(payload.printerPort || PRINTER_PORT || 9100);

    console.log('');
    console.log('========================================');
    console.log('[print test request]');
    console.log('printerIp:', printerIp);
    console.log('printerPort:', printerPort);
    console.log('========================================');
    console.log('');

    const buffer = buildTestReceipt();
    await sendToPrinter(buffer, {
      printerIp,
      printerPort
    });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print test error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.post('/print/receipt', async (req, res) => {
  try {
    const payload = req.body || {};

    console.log('');
    console.log('========================================');
    console.log('[print receipt request]');
    console.log('storeName:', payload.storeName);
    console.log('tableName:', payload.tableName);
    console.log('receiptNo:', payload.receiptNo);
    console.log('items:', Array.isArray(payload.items) ? payload.items.length : 0);
    console.log('subtotal:', payload.subtotal);
    console.log('tax:', payload.tax);
    console.log('total:', payload.total);
    console.log('paymentMethod:', payload.paymentMethod);
    console.log('printerIp:', payload.printerIp || PRINTER_IP);
    console.log('printerPort:', payload.printerPort || PRINTER_PORT);
    console.log('========================================');
    console.log('');

    const buffer = buildReceipt(payload);

    await sendToPrinter(buffer, {
    printerIp: payload.printerIp,
    printerPort: payload.printerPort
    });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print receipt error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.post('/print/label', async (req, res) => {
  try {
    const payload = req.body || {};
    const printerIp = payload.printerIp || PRINTER_IP;
    const printerPort = Number(payload.printerPort || payload.port || PRINTER_PORT || 9100);
    const labels = Array.isArray(payload.labels) ? payload.labels : [];

    console.log('');
    console.log('========================================');
    console.log('[print label request]');
    console.log('printerIp:', printerIp);
    console.log('printerPort:', printerPort);
    console.log('labels:', labels.length);
    console.log('symbology:', payload.symbology);
    console.log('labelSize:', `${payload.labelWidthMm}x${payload.labelHeightMm}mm gap=${payload.gapMm}`);
    console.log('========================================');
    console.log('');

    if (labels.length === 0) {
      res.status(400).json({ ok: false, error: '印刷するラベルがありません' });
      return;
    }

    const buffer = buildLabelTPCL(payload);

    await sendToPrinter(buffer, { printerIp, printerPort });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print label error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.listen(BRIDGE_PORT, () => {
  console.log('');
  console.log('========================================');
  console.log(' Mobile Order Print Bridge');
  console.log('========================================');
  console.log(`Bridge URL : http://localhost:${BRIDGE_PORT}`);
  console.log(`Printer    : ${PRINTER_IP}:${PRINTER_PORT}`);
  console.log('');
  console.log('Health check:');
  console.log(`curl http://localhost:${BRIDGE_PORT}/health`);
  console.log('');
  console.log('Test print:');
  console.log(`curl -X POST http://localhost:${BRIDGE_PORT}/print/test`);
  console.log('========================================');
  console.log('');
});