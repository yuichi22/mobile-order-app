#!/bin/bash

cd "$(dirname "$0")"

echo ""
echo "========================================"
echo " Mobile Order Print Bridge"
echo "========================================"
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js が見つかりません。"
  echo "先に Node.js をインストールしてください。"
  echo "https://nodejs.org/"
  echo ""
  read -p "Enterキーで終了します..."
  exit 1
fi

if [ ! -d "node_modules" ]; then
  echo "初回起動のため、必要なパッケージをインストールします..."
  npm install
fi

echo ""
echo "印刷ブリッジを起動します。"
echo "このウィンドウは閉じないでください。"
echo ""

npm start

echo ""
read -p "Enterキーで終了します..."
