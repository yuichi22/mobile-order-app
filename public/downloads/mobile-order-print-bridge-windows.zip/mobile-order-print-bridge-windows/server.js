// server.js
// Mobile Order local print bridge for LAN ESC/POS printer
// Target: SII RP-D10 / LAN / RAW 9100

const iconv = require('iconv-lite');
const express = require('express');
const cors = require('cors');
const net = require('net');

const app = express();

app.use(cors());
app.use(express.json({ limit: '2mb' }));

const PRINTER_IP = process.env.PRINTER_IP || '192.168.0.100';
const PRINTER_PORT = Number(process.env.PRINTER_PORT || 9100);
const BRIDGE_PORT = Number(process.env.PORT || 8787);
// 版数(住所/TEL/登録番号/税率別対象額/会計No/券名 対応)。/health と起動ログで最新か判別できる。
const BRIDGE_VERSION = '2026-07-16-receipt-v2';

// ラベルプリンタに最後に送ったラベルサイズ(D命令)のキー。同じサイズなら D + 頭出しFeed を
// 再送しない(再送ると毎回空送り＆位置ずれの原因)。サイズ/センサ変更時のみ再送する。
let lastLabelSizeKey = null;

const ESC = '\x1b';
const GS = '\x1d';

const FS = '\x1c';

const pushJapaneseMode = (chunks) => {
  // Initialize
  chunks.push(raw(`${ESC}@`));

  // International character set: Japan
  chunks.push(raw(`${ESC}R\x08`));

  // Character code table候補
  chunks.push(raw(`${ESC}t\x01`));

  // Kanji mode ON
  chunks.push(raw(`${FS}&`));

  // Kanji code system: Shift_JIS
  chunks.push(raw(`${FS}C\x01`));
};

const encodeText = (text = '') => {
  return iconv.encode(String(text), 'cp932');
};

const raw = (value = '') => {
  return Buffer.from(value, 'binary');
};

const formatYen = (value) => {
  const n = Math.round(Number(value || 0));
  return `¥${n.toLocaleString('ja-JP')}`;
};

const normalizeItemName = (item = {}) => {
  return (
    item.name ||
    item.itemName ||
    item.productName ||
    item.menuName ||
    item.title ||
    '商品'
  );
};

const normalizeQuantity = (item = {}) => {
  return Number(item.quantity ?? item.qty ?? item.count ?? 1) || 1;
};

const normalizeLineTotal = (item = {}) => {
  const quantity = normalizeQuantity(item);
  const explicitTotal =
    item.totalPrice ??
    item.lineTotal ??
    item.total ??
    item.amountTotal;

  if (explicitTotal != null) {
    return Number(explicitTotal) || 0;
  }

  const unitPrice =
    item.price ??
    item.unitPrice ??
    item.amount ??
    0;

  return (Number(unitPrice) || 0) * quantity;
};

const fitLine = (left, right, width = 32) => {
  const l = String(left || '');
  const r = String(right || '');
  const space = Math.max(width - l.length - r.length, 1);
  return `${l}${' '.repeat(space)}${r}`;
};

const sendToPrinter = (buffer, options = {}) => {
  const printerIp = options.printerIp || PRINTER_IP;
  const printerPort = Number(options.printerPort || PRINTER_PORT || 9100);

  return new Promise((resolve, reject) => {
    const socket = new net.Socket();

    let settled = false;

    const finish = () => {
      if (settled) return;
      settled = true;
      resolve();
    };

    const fail = (error) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      reject(error);
    };

    socket.setTimeout(5000);

    socket.connect(printerPort, printerIp, () => {
      socket.write(buffer, () => {
        socket.end();
        finish();
      });
    });

    socket.on('error', fail);

    socket.on('timeout', () => {
      fail(new Error(`Printer connection timeout: ${printerIp}:${printerPort}`));
    });
  });
};

const buildTestReceipt = () => {
  const chunks = [];

  // initialize
  chunks.push(raw(`${ESC}@`));
 pushJapaneseMode(chunks);

  // center
  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(encodeText('Mobile Order\n'));
  chunks.push(encodeText('印刷テスト\n'));
  chunks.push(encodeText('------------------------------\n'));

  // left
  chunks.push(raw(`${ESC}a\x00`));
  chunks.push(encodeText(`Printer: ${PRINTER_IP}:${PRINTER_PORT}\n`));
  chunks.push(encodeText(`Time: ${new Date().toLocaleString('ja-JP')}\n`));
  chunks.push(encodeText('------------------------------\n'));
  chunks.push(encodeText('テーブル: A1\n'));
  chunks.push(encodeText('商品: テスト商品\n'));
  chunks.push(encodeText('数量: 1\n'));
  chunks.push(encodeText(`金額: ${formatYen(500)}\n`));
  chunks.push(encodeText('------------------------------\n'));
  chunks.push(raw(`${ESC}a\x01`));
  chunks.push(encodeText('ありがとうございました\n'));

  // feed
  chunks.push(encodeText('\n\n\n'));

  // partial/full cut
  chunks.push(raw(`${GS}V\x00`));

  return Buffer.concat(chunks);
};

const resolveAmount = (...values) => {
  for (const value of values) {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return 0;
};

const normalizePaymentMethodLabel = (method = '') => {
  const key = String(method || '').toLowerCase();
  if (key === 'cash') return '現金';
  if (key === 'card' || key === 'credit') return 'カード';
  if (key === 'qr' || key === 'paypay') return 'QR決済';
  return String(method || '');
};

// ---- STAR(iPad)レシートと同一レイアウトの整形ヘルパ ----
// 桁数(SII RP-D10=58mm/32桁想定)。80mm機なら 48 に変更すると STAR と同じ幅になる。
const RECEIPT_COLS = 32;

// 全角(コードポイント>0x2000)を2桁として数える表示幅(STAR側 displayWidth と同じ)。
const dispWidth = (s = '') => {
  let w = 0;
  for (const ch of String(s)) w += (ch.codePointAt(0) > 0x2000 ? 2 : 1);
  return w;
};

// 左ラベル＋右金額を桁幅に合わせて配置(STAR lr と同等)。入り切らなければ右を次行右寄せ。
const lrLine = (left, right, cols = RECEIPT_COLS) => {
  const l = String(left || '');
  const r = String(right || '');
  const used = dispWidth(l) + dispWidth(r);
  if (used + 1 <= cols) {
    return `${l}${' '.repeat(Math.max(1, cols - used))}${r}\n`;
  }
  const pad = Math.max(0, cols - dispWidth(r));
  return `${l}\n${' '.repeat(pad)}${r}\n`;
};

// 右寄せ1行(宛名の下線用)。
const rightLine = (s = '', cols = RECEIPT_COLS) => `${' '.repeat(Math.max(0, cols - dispWidth(s)))}${s}\n`;

const buildReceipt = (payload = {}) => {
  const {
    storeName = 'Mobile Order',
    address = '',
    tel = '',
    invoiceNumber = '',
    tableName = '',
    registerName = '',
    receiptNo = '',
    issuedAtText = '',
    items = [],
    paymentMethod = '',
    title = '領収書',
    headerTitle = '',
    footerNote = '',
    hideRecipientAndProviso = false,
    note = ''
  } = payload;

  const subtotal = resolveAmount(payload.subtotal, payload.subTotal);
  const tax = resolveAmount(payload.tax, payload.taxAmount);
  const taxAmountReduced = resolveAmount(payload.taxAmountReduced);
  const taxAmountStandard = resolveAmount(payload.taxAmountStandard);
  // 税率別の税込対象額(税率ごとの対価の合計額)。
  const taxableIncludedReduced = resolveAmount(payload.taxableIncludedReduced);
  const taxableIncludedStandard = resolveAmount(payload.taxableIncludedStandard);
  const taxRateReduced = resolveAmount(payload.taxRateReduced) || 8;
  const taxRateStandard = resolveAmount(payload.taxRateStandard) || 10;
  const discountAmount = resolveAmount(payload.discountAmount, payload.discount);
  const total = resolveAmount(payload.total, payload.totalAmount, payload.totalPrice);
  const discountLines = Array.isArray(payload.discounts)
    ? payload.discounts.filter((d) => resolveAmount(d && d.amount) > 0)
    : [];

  const chunks = [];
  const t = (s = '') => chunks.push(encodeText(`${s}\n`));
  const lr = (left, right) => chunks.push(encodeText(lrLine(left, right)));
  const cCenter = () => chunks.push(raw(`${ESC}a\x01`));
  const cLeft = () => chunks.push(raw(`${ESC}a\x00`));
  const sReset = () => chunks.push(raw(`${ESC}!\x00`));
  const sBold = () => chunks.push(raw(`${ESC}!\x08`));
  const sTitle = () => chunks.push(raw(`${ESC}!\x38`)); // 太字＋縦横2倍(短いタイトル用)
  const sTall = () => chunks.push(raw(`${ESC}!\x10`));  // 縦2倍(合計強調・桁ずれ回避)
  const divider = () => t('-'.repeat(RECEIPT_COLS));

  chunks.push(raw(`${ESC}@`));
  pushJapaneseMode(chunks);

  // 0. 上部余白
  t('');

  // 1. タイトル（大・中央・太字）
  cCenter();
  sTitle();
  t(title && title !== '領収書' ? title : '領　収　書');
  sReset();
  t('');

  // 2. バナー画像: RP-D10 の ESC/POS 経路では非対応のため省略(この店舗は banner 空)

  // 3. ヘッダー文言（レシート設定・あれば）
  if (headerTitle) t(headerTitle);
  t('');

  // 4. 店名・住所・TEL・登録番号（中央）
  if (storeName) { sBold(); t(storeName); sReset(); }
  if (address) t(address);
  if (tel) t(`TEL: ${tel}`);
  if (invoiceNumber) t(`登録番号: ${invoiceNumber}`);
  cLeft();
  divider();

  // 5. 日付 / No / テーブル / 使用レジ名
  t(issuedAtText || new Date().toLocaleString('ja-JP'));
  if (receiptNo) t(`No: ${receiptNo}`);
  if (tableName) t(tableName);
  if (registerName) t(`レジ: ${registerName}`);

  // 6. 宛名（右寄せ下線＋様）
  if (!hideRecipientAndProviso) {
    t('');
    chunks.push(encodeText(rightLine('________________  様')));
    t('');
  }
  divider();

  // 明細（商品名＋行計 / 単価×数量 / 商品個別割引）
  const normalizedItems = Array.isArray(items) ? items : [];
  if (normalizedItems.length === 0) t('商品明細なし');
  for (const item of normalizedItems) {
    const name = normalizeItemName(item);
    const quantity = normalizeQuantity(item);
    const unitPrice = resolveAmount(item.unitPrice, item.price, item.amount);
    const lineTotal = normalizeLineTotal(item);
    lr(name, formatYen(lineTotal));
    if (unitPrice > 0 && quantity > 0) t(`  ${formatYen(unitPrice)} x ${quantity}`);
    const ld = item.lineDiscount;
    if (ld && resolveAmount(ld.amount) > 0) lr(`  ${ld.label || '値引き'}`, `-${formatYen(ld.amount)}`);
  }
  divider();

  // 金額
  lr('小計', formatYen(subtotal));
  if (discountLines.length > 0) {
    for (const line of discountLines) lr(line.label || '値引き', `-${formatYen(line.amount)}`);
  } else if (discountAmount > 0) {
    lr('値引き', `-${formatYen(discountAmount)}`);
  }
  if (taxableIncludedReduced > 0) {
    lr(`${taxRateReduced}%対象`, formatYen(taxableIncludedReduced));
    lr(`  (内消費税 ${taxRateReduced}%)`, formatYen(taxAmountReduced));
  } else if (taxAmountReduced > 0) {
    lr(`(内消費税 ${taxRateReduced}%)`, formatYen(taxAmountReduced));
  }
  if (taxableIncludedStandard > 0) {
    lr(`${taxRateStandard}%対象`, formatYen(taxableIncludedStandard));
    lr(`  (内消費税 ${taxRateStandard}%)`, formatYen(taxAmountStandard));
  } else if (taxAmountStandard > 0) {
    lr(`(内消費税 ${taxRateStandard}%)`, formatYen(taxAmountStandard));
  }
  if (taxAmountReduced === 0 && taxAmountStandard === 0) {
    lr('(内消費税)', formatYen(tax));
  }

  // 合計（縦2倍で強調）
  sTall();
  lr('合計', formatYen(total));
  sReset();

  // お支払（buildTender の内訳文字列をそのまま）
  if (paymentMethod) lr('お支払', String(paymentMethod));

  // 注記（会計明細など）
  if (note) {
    divider();
    const noteText = String(note);
    for (let i = 0; i < noteText.length; i += 30) t(noteText.slice(i, i + 30));
  }
  divider();

  // フッタ（中央）
  t('');
  cCenter();
  t(footerNote || (title === '会計明細' ? '会計内訳です' : 'ご利用ありがとうございました。'));
  cLeft();
  t('');
  t('');

  // カット
  chunks.push(raw(`${GS}V\x00`));

  return Buffer.concat(chunks);
};

// ============================================================
// ラベル印刷（東芝テック B-EV4T / TPCL / RAW TCP 9100）
// ------------------------------------------------------------
// TPCL (TEC Printer Command Language) でバーコードラベルを生成する。
// 制御コードは標準モード（ヘッダ '{' / 区切り '|' / 終端 '}'）で、
// 各コマンドは `{` で始まり `|}` で終わる。座標・寸法はすべて 0.1mm 単位。
//
// ※ XB(バーコード)/PC(文字)/XS(発行) の細かな引数は B-EV4T の TPCL
//   リファレンス依存。実機で1枚通しながら調整する前提で、レイアウト値・
//   倍率・モジュール幅・濃度・速度は payload / 既定値から可変にしている。
// ============================================================

// アプリ側のバーコード種別名 → TPCL XB コマンドのバーコードタイプ。
const TPCL_BARCODE_TYPE = {
  jan13: '5', // JAN13 / EAN13
  ean13: '5',
  jan8: '0', // JAN8 / EAN8
  ean8: '0',
  code128: '9', // CODE128
  code39: '3', // CODE39
  nw7: '4', // NW-7 (Codabar)
  itf: '2' // Interleaved 2 of 5
};

// 0.1mm 値を 4 桁ゼロ詰めへ。
const tpclCoord = (value) => String(Math.max(0, Math.round(Number(value) || 0))).padStart(4, '0');

// TPCL のデータフィールドに使えない制御文字（| や 改行）を除去する。
const sanitizeTpclText = (text = '') =>
  String(text == null ? '' : text)
    .replace(/[|{}]/g, ' ')
    .replace(/[\r\n\t]/g, ' ')
    .trim();

// 文字列のおおよその印字幅(0.1mm)。右寄せ位置の概算用(font B 基準・実機で要調整)。
// 全角(コードポイント>0xFF)は約1.5mm、半角は約0.9mm × 横倍率。
const estimateTextWidthU = (text = '', widthMag = 1) => {
  let units = 0;
  for (const ch of String(text)) {
    const code = ch.codePointAt(0);
    units += (code > 0xff ? 15 : 9) * widthMag;
  }
  return units;
};

// 1 枚分のラベル TPCL を組み立てる。
const buildLabelCommands = (label = {}, options = {}) => {
  const {
    symbology = 'code128',
    labelWidthMm = 30,
    moduleWidthDots = 2,
    barcodeHeightMm = 5,
    showName = true,
    showPrice = true,
    showBarcodeNumber = false
  } = options;

  const barcodeType = TPCL_BARCODE_TYPE[String(symbology).toLowerCase()] || '9';
  const widthU = Math.round(labelWidthMm * 10);
  // 印字可能域 約1mm〜12mm(13mmラベル, 上下1mmはスローアップ/ダウンで印字不可)に収める。
  // 番号(バーコード下の数字)を出す時は、その2.0mm分の余白を作るためバーコードを低めにする。
  const showNum = Boolean(showBarcodeNumber);
  // 印字可能下端は約110(末尾マージン)。バーコード上端 y=72。番号ONは番号行(帯90-110)を確保
  // するためバー下端を約90に(上限18)。番号OFFは番号行が無いのでバーを約108まで(上限36)。
  const barcodeH = Math.min(Math.round(barcodeHeightMm * 10), showNum ? 18 : 36);
  const mw = String(Math.max(1, Math.min(15, moduleWidthDots))).padStart(2, '0');

  const sku = sanitizeTpclText(label.sku);
  const name = sanitizeTpclText(label.name);
  const colorName = sanitizeTpclText(label.colorName);
  const size = sanitizeTpclText(label.size);
  const barcodeData = sanitizeTpclText(label.barcode);
  const price = label.price != null && label.price !== '' ? formatYen(label.price) : '';

  // レイアウト（0.1mm単位 / 例 30×13mm = widthU 300）:
  //  1段目: 品番(左) ／ 税込・価格(右)
  //  2段目: 名称(太)
  //  3段目: バーコード(左) ／ 色(右上)・サイズ(右下)
  // ※座標・倍率は B-EV4T 実機で調整する前提。バーコード幅が広いと右側の色/サイズと
  //   重なるため、モジュール幅(細さ)や barcodeSource(品番/JAN) で調整する。
  const xL = 12; // 左マージン
  const rightMargin = 8; // 右マージン(右寄せ用)
  // 右寄せのX座標を文字幅から逆算する。
  const rightAlignedX = (text, widthMag = 1) =>
    Math.max(xL, widthU - rightMargin - estimateTextWidthU(text, widthMag));

  const commands = ['{C|}'];

  // TPCL BIT MAP FONT (PC) コマンド書式（B-EV4仕様）:
  //   {PCnnn;X,Y,横倍率,縦倍率,フォント,回転(2桁),属性=データ|}
  //   ・データは「=」で渡す。回転2桁。属性B=黒文字。フォントU=漢字16x16(ANK+漢字)。
  //   ★文字の印字原点 Y は「文字の下端」基準で、文字は上方向に描かれる。
  //     よって各PCの Y = その文字の下端(0.1mm)。バーコード(XB)の Y は上端でバーは下方向。
  const F = 'U';

  // バーコード幅(JAN13概算)。色/サイズの左詰め開始位置に使う。
  const barcodeWidthU = Math.round(95 * Math.max(1, moduleWidthDots) * 1.1);
  // 色/サイズは「バーコード右端の少し右」から左詰め。長い色名(ピンク/グレー等)が右で切れにくい
  // よう、バーコードに被らない範囲でできるだけ左に寄せる(右端から約9mm手前までクランプ)。
  const xRightCol = Math.min(xL + barcodeWidthU + 6, widthU - 90);

  // 縦座標(0.1mm, 文字Yは下端)。実測: 上余白1mm/内容9mm/下余白3mm。下の約2mmが印字可の
  // ため内容を下へ広げ、バーコードを高くする。印字可能下端 約118に収める。
  const yKuban = 30; // 品番(下端)
  const yPrice = 52; // 価格(下端)。品番と重ならないようブロックごと約1mm下げ(帯16-52)。
  const yName = 70; // 名称(下端)
  const yBarTop = 72; // バーコード上端(バーは下方向)
  const yColor = 88; // 色(下端)。サイズ行(90-110)と重ならないよう上げる。
  const yBottom = 110; // サイズ/番号(下端)。末尾マージンのため 印字可能下端 約110 に収める。

  // 1段目: 品番(左) ／ 価格(右)。価格は「¥金額=太字大(フォントC)」＋「税込=小(フォントU)」。
  if (sku) {
    // タイトル「品番：」は付けず、内容を左端から表示
    commands.push(`{PC001;${tpclCoord(xL)},${tpclCoord(yKuban)},1,1,${F},00,B=${sku}|}`);
  }
  if (showPrice && price) {
    const tax = '税込';
    const taxW = estimateTextWidthU(tax, 1); // 税込(フォントU)幅
    const xTax = Math.max(xL, widthU - rightMargin - taxW); // 税込を右端に
    // ¥金額: フォントC(Times Bold)で太字・大きめ。文字間隔を-02で詰める(narrow)。
    // フォントCは比例幅なので文字種別で幅を見積る(数字/¥≈19, カンマ/ピリオド≈8)。カンマ無しの
    // 短い金額(¥439等)が右へはみ出て税込に接触する問題を防ぐ。税込のすぐ左に右寄せ(間隔9)。
    let yenW = 0;
    for (const ch of price) yenW += ch === ',' || ch === '.' ? 8 : 19;
    const xYen = Math.max(xL, xTax - 9 - yenW);
    commands.push(`{PC002;${tpclCoord(xYen)},${tpclCoord(yPrice)},1,1,C,-02,00,B=${price}|}`);
    commands.push(`{PC003;${tpclCoord(xTax)},${tpclCoord(yPrice)},1,1,${F},00,B=${tax}|}`);
  }

  // 2段目（名称）: タイトル「名称」は付けず、内容を左端から表示
  if (showName && name) {
    commands.push(`{PC005;${tpclCoord(xL)},${tpclCoord(yName)},1,1,${F},00,B=${name}|}`);
  }

  // 3段目（バーコード=左 ／ 色=右上・サイズ=右下を左詰め ／ 番号=バー下に自前描画）
  if (barcodeData) {
    commands.push(`{XB01;${tpclCoord(xL)},${tpclCoord(yBarTop)},${barcodeType},1,${mw},0,${tpclCoord(barcodeH)}=${barcodeData}|}`);
    // バーコード番号: バーコードの下に、左端を揃えて等倍で描く(はみ出し防止のため文字間隔なし)。
    if (showNum) {
      commands.push(`{PC008;${tpclCoord(xL)},${tpclCoord(yBottom)},1,1,${F},00,B=${barcodeData}|}`);
    }
  }
  // 色・サイズ：バーコード右側に左詰め
  if (colorName) {
    commands.push(`{PC006;${tpclCoord(xRightCol)},${tpclCoord(yColor)},1,1,${F},00,B=${colorName}|}`);
  }
  if (size) {
    commands.push(`{PC007;${tpclCoord(xRightCol)},${tpclCoord(yBottom)},1,1,${F},00,B=${size}|}`);
  }

  return commands;
};

const buildLabelTPCL = (payload = {}) => {
  const {
    labels = [],
    labelWidthMm = 30, // ラベル幅（印字ヘッド方向＝Xの有効幅）
    labelHeightMm = 13, // ラベル送り方向の長さ
    gapMm = 0, // ラベル間ギャップ（隙間）。黒線連続紙は 0
    mediaSensor = 'blackmark', // 用紙センサー: blackmark=反射/gap=透過/none=なし
    printSpeed = 3, // 印字速度(ips相当の指定値)。実機に合わせ調整。
    copies = 1
  } = payload;

  // 発行(XS)コマンドのセンサー種別digit。2=透過(ギャップ) / 1=反射(ブラックマーク) / 0=なし(連続)
  const sensorDigit = { gap: '2', blackmark: '1', none: '0' }[String(mediaSensor).toLowerCase()] || '2';

  const widthU = Math.round(labelWidthMm * 10);
  // ピッチ = 用紙1周期。黒線(反射)用紙は「黒線〜次の黒線＝ラベル長」でギャップは無い。
  // ギャップを加算すると ピッチ>ラベル長 になり、下記の「長さ<ピッチ」問題を招くため、
  // 黒線用紙ではギャップを無視してピッチ=ラベル長にする。透過(gap)用紙のみギャップを加算。
  const isBlackmark = String(mediaSensor).toLowerCase() === 'blackmark';
  const pitchU = isBlackmark
    ? Math.round(labelHeightMm * 10)
    : Math.round((labelHeightMm + Number(gapMm || 0)) * 10);
  // 有効印字長＝ピッチに一致させる。
  // ※有効印字長>ピッチ にすると赤エラーで印刷不可(プリンタが拒否)。<ピッチ だと末尾に
  //   非印字エリアができFEEDが狂う。=ピッチ が唯一安定。末尾約2mmは非印字マージンになる。
  const heightU = pitchU;
  void lastLabelSizeKey; // 互換のため残置(未使用)

  const lines = [];

  // ラベルサイズ設定(毎回同じ値を送る。停止位置=黒線になるためFEEDは狂わない)。
  lines.push(`{D${tpclCoord(pitchU)},${tpclCoord(widthU)},${tpclCoord(heightU)}|}`);

  const normalizedLabels = Array.isArray(labels) ? labels : [];

  for (const label of normalizedLabels) {
    const labelCopies = Math.max(1, Math.min(999, Number(label.copies ?? copies ?? 1)));

    lines.push(...buildLabelCommands(label, { ...payload, labelHeightMm }));

    // 発行: {XS;I, 枚数, 000<センサ>C<速度><リボン><回転><応答> |}
    //  例 {XS;I,0001,0001C3000|} = カット無し/反射センサ/速度3/直感熱(リボン0)/回転0/応答無し
    //  センサ digit: 2=透過 1=反射(黒線) 0=なし。カッタ構成に合わせ先頭3桁は000(カット無し)。
    lines.push(
      `{XS;I,${String(labelCopies).padStart(4, '0')},000${sensorDigit}C${String(printSpeed).padStart(1, '0')}000|}`
    );
  }

  // 各コマンドは CR+LF 区切りで送出する。日本語(税込/名称/商品名)を含むため
  // Shift-JIS(CP932)でエンコードする。latin1だと日本語が化けてTPCLの区切り(|})を壊す。
  return iconv.encode(lines.join('\r\n') + '\r\n', 'cp932');
};

app.get('/health', (req, res) => {
  res.json({
    ok: true,
    bridge: 'mobile-order-print-bridge',
    version: BRIDGE_VERSION,
    printerIp: PRINTER_IP,
    printerPort: PRINTER_PORT,
    bridgePort: BRIDGE_PORT
  });
});

app.post('/print/test', async (req, res) => {
  try {
    const payload = req.body || {};
    const printerIp = payload.printerIp || PRINTER_IP;
    const printerPort = Number(payload.printerPort || PRINTER_PORT || 9100);

    console.log('');
    console.log('========================================');
    console.log('[print test request]');
    console.log('printerIp:', printerIp);
    console.log('printerPort:', printerPort);
    console.log('========================================');
    console.log('');

    const buffer = buildTestReceipt();
    await sendToPrinter(buffer, {
      printerIp,
      printerPort
    });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print test error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.post('/print/receipt', async (req, res) => {
  try {
    const payload = req.body || {};

    console.log('');
    console.log('========================================');
    console.log('[print receipt request]');
    console.log('storeName:', payload.storeName);
    console.log('tableName:', payload.tableName);
    console.log('receiptNo:', payload.receiptNo);
    console.log('items:', Array.isArray(payload.items) ? payload.items.length : 0);
    console.log('subtotal:', payload.subtotal);
    console.log('tax:', payload.tax);
    console.log('total:', payload.total);
    console.log('paymentMethod:', payload.paymentMethod);
    console.log('printerIp:', payload.printerIp || PRINTER_IP);
    console.log('printerPort:', payload.printerPort || PRINTER_PORT);
    console.log('========================================');
    console.log('');

    const buffer = buildReceipt(payload);

    await sendToPrinter(buffer, {
    printerIp: payload.printerIp,
    printerPort: payload.printerPort
    });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print receipt error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.post('/print/label', async (req, res) => {
  try {
    const payload = req.body || {};
    const printerIp = payload.printerIp || PRINTER_IP;
    const printerPort = Number(payload.printerPort || payload.port || PRINTER_PORT || 9100);
    const labels = Array.isArray(payload.labels) ? payload.labels : [];

    console.log('');
    console.log('========================================');
    console.log('[print label request]');
    console.log('printerIp:', printerIp);
    console.log('printerPort:', printerPort);
    console.log('labels:', labels.length);
    console.log('symbology:', payload.symbology);
    console.log('mediaSensor:', payload.mediaSensor);
    console.log('labelSize:', `${payload.labelWidthMm}x${payload.labelHeightMm}mm gap=${payload.gapMm}`);
    console.log('========================================');
    console.log('');

    if (labels.length === 0) {
      res.status(400).json({ ok: false, error: '印刷するラベルがありません' });
      return;
    }

    const buffer = buildLabelTPCL(payload);

    console.log('---- TPCL ----');
    console.log(buffer.toString('latin1'));
    console.log('---- /TPCL ----');
    console.log('');

    await sendToPrinter(buffer, { printerIp, printerPort });

    res.json({ ok: true });
  } catch (error) {
    console.error('[print label error]', error);
    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.listen(BRIDGE_PORT, () => {
  console.log('');
  console.log('========================================');
  console.log(' Mobile Order Print Bridge');
  console.log('========================================');
  console.log(`Version    : ${BRIDGE_VERSION}`);
  console.log(`Bridge URL : http://localhost:${BRIDGE_PORT}`);
  console.log(`Printer    : ${PRINTER_IP}:${PRINTER_PORT}`);
  console.log('');
  console.log('Health check:');
  console.log(`curl http://localhost:${BRIDGE_PORT}/health`);
  console.log('');
  console.log('Test print:');
  console.log(`curl -X POST http://localhost:${BRIDGE_PORT}/print/test`);
  console.log('========================================');
  console.log('');
});